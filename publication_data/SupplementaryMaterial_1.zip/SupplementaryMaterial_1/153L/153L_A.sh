#!/bin/sh
#SBATCH --mem=16000
#SBATCH -o batch_153L_A_%j.log
#SBATCH -e batch_153L_A_%j.err

cd /homes/users/boliva/baldo_data/DI/examples

csh run_raDI_exe2.sh 153L A 153l 53

